---
name: resume-tailor
description: Automatically tailors and rewrites a resume to match a specific job opening. Use whenever the user uploads or pastes both a resume and a job description and asks to customize, tailor, optimize, or rewrite the resume for that role. Also triggers for phrases like "update my resume for this job", "make my resume fit this posting", "tailor my CV", or "optimize my resume for this application". Requires both a resume AND a job description to proceed — if either is missing, ask for it before starting.
---

# Resume Tailor

Rewrites and reformats a resume to be optimally targeted to a specific job opening. Output is a polished, download-ready `.docx` and/or `.pdf` file — ATS-safe by default.

Before writing any code, read `/mnt/skills/public/docx/SKILL.md` for instructions on creating Word documents correctly. Also read `/mnt/skills/public/pdf/SKILL.md` if PDF output is requested.

---

## Step 1: Intake — Collect Both Documents

**Do not proceed without both.** If either is missing, ask:

> "To tailor your resume I'll need two things:
> 1. **Your current resume** — upload as a PDF, Word doc (.docx), or paste the text directly. All three formats work.
> 2. **The job description** — paste the full posting, or share the URL.
>
> Once I have both I'll ask one quick question about layout."

**Handling PDF resumes:**
- Use the pdf skill to extract the full text content
- Note to the user that exact original formatting won't carry over (PDF layout cannot be read structurally), and that the chosen layout template will be applied fresh
- Proceed with the extracted text as the content source

Wait for both documents before proceeding.

---

## Step 2: Analyse the Gap

Before rewriting, silently analyse both documents to identify:

**From the job description, extract:**
- The role title and seniority level
- The top 5–8 required or strongly preferred skills/competencies
- Key action words and phrases the employer uses (mirror these back in the resume)
- Must-have qualifications (years of experience, specific tools, certifications)
- Any soft skills or cultural signals ("fast-paced", "collaborative", "data-driven")
- ATS-sensitive keywords — exact phrases from the posting that should appear verbatim

**From the resume, identify:**
- Experiences and achievements that directly map to the job requirements
- Gaps — things the job asks for that aren't currently surfaced
- Buried strengths — relevant experience that exists but isn't framed for this role
- Language mismatches — where the candidate's phrasing differs from the employer's

---

## Step 3: Ask About Layout

Present the four options clearly:

> "One quick question before I start: which layout would you like?
>
> **A — Keep my current layout** — I'll rewrite the content but preserve your existing design and structure.
>
> **B — Two-column professional** — Your name and a bold color sidebar on the left with contact details and skills; clean experience column on the right. Confident and editorial — works well for creative, marketing, events, and communications roles.
>
> **C — Dark sidebar contrast** — A rich dark-colored left panel containing your name (large, in white), contact, and skills; a clean white right column for experience. High contrast, typographically bold — best for creative directors, copywriters, brand strategists, senior individual contributors.
>
> **D — Executive single-column** — Clean, airy single-column layout. Your name large at the top, a thin rule, subtle accent color on section headers only, generous whitespace. Understated authority — ideal for executives, lawyers, consultants, finance, and sales leaders.
>
> Which feels right for the role you're applying for?"

Wait for their answer.

---

## Step 4: Rewrite the Content

Apply all of the following — this is the core of the skill:

### Summary / Profile
- Rewrite the summary to speak directly to this specific role
- Open with the job title (or close equivalent) the employer is hiring for
- Incorporate 2–3 of the employer's exact keywords naturally
- Lead with the candidate's most relevant strength for this role, not their most recent job
- Keep to 3–4 lines maximum — tight and punchy

### Experience Bullets
For each role, rewrite bullets using this method:

1. **Keep only what's relevant** — if a bullet has no bearing on the target role, cut or compress it
2. **Reframe for relevance** — reframe existing experience using the employer's language where truthful
3. **Lead with impact** — start bullets with strong action verbs; put the result before the method where possible
4. **Mirror keywords** — use exact phrases from the job description where the experience genuinely matches (e.g. if the job says "cross-functional collaboration", use that phrase, not "worked across teams")
5. **Quantify where possible** — if the original resume has numbers, keep them; if not, prompt the user once at the end to add them

### Skills Section
- Reorder or rewrite to surface the skills most relevant to this role first
- Remove skills that are irrelevant to this application
- Add any skills mentioned in the job description that the candidate genuinely has but didn't list

### Job Titles
- If the candidate's actual title is a close variant of the hiring title, note this subtly. Do not fabricate or inflate titles — accuracy is non-negotiable.

### What NOT to change
- Employment dates — never alter
- Company names — never alter  
- Claimed qualifications, certifications, or degrees — never fabricate or embellish
- Core facts — only framing and emphasis may change, never substance

---

## Step 4b: ATS Compliance — Critical Requirements

**This step is non-negotiable regardless of which layout is chosen.** Most employers run resumes through Applicant Tracking Systems (ATS) before a human ever sees them. A beautiful resume that fails ATS parsing is invisible.

### What ATS systems do
ATS bots parse resume text into structured fields: name, contact, work history, education, skills. They then score the resume against the job description by matching keywords and phrases. A resume fails ATS when the bot cannot read the text, or when the keywords don't match.

### ATS rules — enforce all of these:

**Text must be real, selectable text — never images of text**
- All content must be typed text in the docx, not embedded as images or graphics
- Do not use text boxes for any content that must be read by ATS (contact info, job titles, dates, bullet points) — text boxes are frequently skipped by parsers
- If the design uses a table (for two-column layouts), ensure table cells contain plain text, not nested text boxes

**Fonts and encoding**
- Use only standard, widely-installed fonts: Calibri, Arial, Garamond, Georgia, Times New Roman, Cambria — never decorative or downloaded fonts that may not render on the employer's system
- All text must be encoded as standard Unicode — no special ligatures, fancy dashes (use standard em dash —), or decorative characters that can corrupt on parsing

**Section headers must use standard labels**
ATS systems are trained to recognise these exact headers. Use them verbatim (casing can vary):
- `Work Experience` or `Experience` or `Professional Experience` — NOT "Career Journey" or "My Story"
- `Education` — NOT "Academic Background"
- `Skills` or `Core Skills` or `Key Skills` — NOT "My Toolkit"
- `Summary` or `Professional Summary` or `Profile` — NOT "About Me"
- `Certifications` — NOT "Credentials"

**No headers or footers for critical content**
- Contact details (email, phone, LinkedIn) must appear in the main document body, not only in the Word header/footer — many ATS parsers skip headers and footers entirely
- Page numbers in footers are fine; nothing else critical should live there

**Keyword density and placement**
- The job title or a close match must appear in the summary section — this is one of the first fields ATS checks
- Each key requirement from the job description should appear at least once in the resume using the employer's exact phrasing — not synonyms, not paraphrases, exact matches
- Skills section must list relevant skills as plain comma-separated text or simple bullet points — not in columns, not as visual bars or rating graphics (ATS cannot read those)
- Avoid cramming keywords unnaturally — ATS systems also flag keyword stuffing; each keyword should appear in a meaningful context

**File format**
- `.docx` is the most universally ATS-compatible format — always produce this first
- `.pdf` is generally safe for modern ATS but occasionally causes parsing errors with complex layouts — warn the user if they choose PDF only
- Never produce `.pages`, `.odt`, or image-based PDFs as the primary submission file

**Layout-specific ATS notes:**
- **Layout A (preserve):** Check the original for text boxes, graphics, or non-standard headers — flag and fix any that exist
- **Layout B (two-column):** Tables are ATS-readable IF content is plain text in cells. Avoid nested tables. Test that all content is selectable text.
- **Layout C (dark sidebar):** The sidebar background color is cosmetic and ATS-safe. Ensure sidebar text (name, contact, skills) is real text in the table cell, not an image or text box overlay.
- **Layout D (single column):** Cleanest for ATS — lowest risk. Verify tab stops for date alignment don't create parsing confusion.

### ATS Self-Check Before Saving
Before generating the final file, verify:
- [ ] All text is selectable (no images of text anywhere)
- [ ] No critical content lives only in text boxes
- [ ] Section headers use standard ATS-recognised labels
- [ ] Contact info appears in the document body
- [ ] Job description keywords appear verbatim in the resume
- [ ] Skills are listed as plain text, not visual graphics
- [ ] Font is one of the standard safe options

---

## Step 5: Build the .docx

Use the docx skill to generate the output. Apply the chosen layout:

---

### Layout A — Preserve Existing

Replicate the visual structure of the uploaded resume as closely as possible. Apply only content changes. Match the original's column count, font choices, section order, and header style. If the original resume has design elements (color bars, icons, photo placeholders), preserve them.

---

### Layout B — Two-Column Professional

**Inspired by:** clean editorial two-column resumes with a colored left accent bar — confident but not aggressive.

**Structure:**
- **Left column** (~30% width): name at top in large bold type, thin accent rule below name, then stacked sections: Contact, Skills, Education, any certifications
- **Right column** (~70% width): Professional Summary, then Experience in reverse chronological order
- **Divider:** a thin vertical line or subtle color band separating columns
- **Color palette:** One restrained accent color used for: column divider, section header rules, and name. Suggested: deep navy (#1a2e4a), forest teal (#1d4a42), charcoal plum (#3a2d45), or warm slate (#2d3748). Never bright or garish.
- **Typography:** Name in bold 22–26pt. Section headers in 8–9pt all-caps with a 1pt rule beneath. Body in 10–10.5pt. Consistent, professional.
- **Spacing:** Generous leading between bullets (at least 4pt after). Section spacing 10–12pt.

**Docx implementation:**
Use a two-column table for the body layout. Set column widths explicitly. Use paragraph styles for consistent formatting. Apply the accent color to the left column background or left border bar.

---

### Layout C — Dark Sidebar Contrast

**Inspired by:** high-contrast editorial resumes popular in creative industries — name displayed very large in white on a dark panel, sharp contrast against a clean white body.

**Structure:**
- **Left sidebar** (~32% width): solid dark background fill. Name displayed large (28–34pt) in white or cream. Below: thin white rule, then Contact, Skills, Education in white/light text. Section labels in small caps, muted light color.
- **Right body** (~68% width): white background. Professional Summary at top, then Experience. Section headers in the same dark sidebar color as a text accent — creating visual coherence.
- **Color palette:** Sidebar color options: near-black (#1a1a1a), deep charcoal (#252525), dark navy (#0f1c2e), dark forest (#152a20). Pair with a single accent: warm gold, soft white, or the sidebar color echoed in section headers on the right.
- **Typography:** Sidebar name 28–34pt bold. Body role titles 11–12pt bold. Body text 10pt. Left sidebar section labels 7–8pt all-caps with spacing.
- **Spacing:** Tight on the sidebar (this is a highlight reel). Generous in the body column.

**Docx implementation:**
Use a table with two columns. Apply background shading to the left cell using the chosen sidebar color. Set all left-column text to white or near-white. Right column stays default background.

---

### Layout D — Executive Single Column

**Inspired by:** clean, authoritative single-column resumes used by executives, consultants, and sales leaders — Apple-store minimalism applied to a Word document.

**Structure:**
- Full-width single column
- Name in large bold type (26–30pt), centered or left-aligned
- Thin horizontal rule below name (0.5–1pt, accent color)
- Contact details in small, spaced type below rule
- Section headers: bold, all-caps, 8–9pt, with a full-width thin rule beneath each — accent color only on these rules, nowhere else
- Experience entries: company/role bold left-aligned, dates right-aligned on the same line, bullets below in 10pt
- **Color palette:** One accent color used only for the name rule and section header rules. Options: deep navy (#1a2e4a), forest green (#1d4040), warm charcoal (#333333), or burgundy (#5c1a1a). Everything else black on white.
- **Whitespace:** This layout lives and dies by breathing room. Minimum 6pt after each bullet, 14–16pt between sections.
- **Typography:** Name 26–30pt bold. Section headers 8–9pt all-caps. Role titles 11pt bold. Body 10–10.5pt. All the same typeface family — Calibri, Georgia, or Garamond are appropriate choices.

**Docx implementation:**
Single-column document with precise paragraph spacing. Use a top horizontal border on section header paragraphs for the rule effect. Right-tab stop at the right margin for date alignment.

---

## Step 6: Final Pass — Quality Check

Before saving the file, verify:

- [ ] Every bullet begins with a strong action verb
- [ ] The job title or a close equivalent appears in the summary
- [ ] At least 4–5 of the job description's key terms appear verbatim in the resume
- [ ] No bullet is longer than two lines
- [ ] Dates, company names, and titles match the original exactly
- [ ] Nothing has been fabricated or inflated
- [ ] The layout is consistent — no rogue fonts, sizes, or spacing

---

## Step 7: Deliver + File Format + Prompt for Numbers

### File naming
Save as: `[FirstName][LastName]_Resume_[CompanyName].docx`
- Use the candidate's full name as it appears on the resume, no spaces
- Use the company name from the job posting, not the role title
- If no company name is available, use the role title instead

### Deliver first, then ask about format
Generate and share the `.docx` file first — this is the universal default and the safest for ATS. After sharing, ask:

> "Here's your tailored resume — ready to download as a Word doc. Would you also like a PDF version for emailing or submitting directly?
> Note: .docx is safer for ATS portals, but PDF is great if you're emailing it or the employer requests it."

Only generate the PDF if the user says yes. If they do, convert the finalized docx to PDF using the pdf skill and share both files.

### Prompt for numbers
After sharing the file(s), ask once:

> "One last thing — are there any numbers I should add? (e.g. team size managed, budget owned, events per year, revenue impact, % improvements) Even rough figures make a significant difference to ATS scoring and to the humans who read past it. Share them and I'll weave them in."

If they provide numbers, update the file(s) and re-share. If not, wrap up.

---

## Edge Cases

- **Resume is already well-tailored:** Tell the user, highlight the 2–3 remaining gaps, and make targeted improvements rather than rewriting everything
- **Job description is vague or very short:** Extract what you can; ask one clarifying question — "What industry/function is this role in?"
- **Candidate is underqualified:** Focus on transferable skills and honest reframing — never fabricate. Note to the user which gaps exist.
- **User wants to keep layout but also change it:** Clarify — "Would you like to keep your current design, or try one of the new layouts?"
- **Resume is in PDF:** Use the pdf skill to extract text. Inform the user the original layout cannot be preserved — apply their chosen layout fresh. This is handled in Step 1.
- **User chooses PDF output only:** Warn them that some ATS systems parse PDF less reliably than .docx, especially with complex layouts. Recommend also keeping a .docx copy even if they don't plan to submit it.
- **Multiple page resume:** All layouts support 2 pages. If content exceeds 2 pages after tailoring, ask the user which roles to condense or cut.
